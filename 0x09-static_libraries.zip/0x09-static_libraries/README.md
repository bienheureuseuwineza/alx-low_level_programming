static libraries is fun
